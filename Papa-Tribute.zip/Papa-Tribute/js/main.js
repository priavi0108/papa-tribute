// Fade in the body for smooth entrance
window.addEventListener('DOMContentLoaded', () => {
  document.body.classList.remove('not-loaded');
});
